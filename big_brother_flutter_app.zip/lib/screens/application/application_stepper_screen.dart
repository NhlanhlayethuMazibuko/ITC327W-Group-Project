import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../models/application_model.dart';
import '../../services/application_service.dart';
import 'application_tracker_screen.dart';

class ApplicationStepperScreen extends StatefulWidget {
  final String unitId;

  const ApplicationStepperScreen({Key? key, required this.unitId}) : super(key: key);

  @override
  State<ApplicationStepperScreen> createState() => _ApplicationStepperScreenState();
}

class _ApplicationStepperScreenState extends State<ApplicationStepperScreen> {
  int _currentStep = 0;
  final _applicationService = ApplicationService();
  bool _isLoading = false;

  // Form Controllers (Populated dynamically from logged-in student)
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _dobController = TextEditingController();

  final _institutionController = TextEditingController(text: 'University of Free State');
  final _studentNumberController = TextEditingController();
  final _yearController = TextEditingController(text: '1st Year');
  bool _isNsfasFunded = true;

  final _parentNameController = TextEditingController();
  final _parentEmailController = TextEditingController();
  final _parentContactController = TextEditingController();
  final _parentRelationshipController = TextEditingController(text: 'Parent');

  // File Picker Document Upload States
  String? _idCopyFileName;
  String? _idCopyFileSize;

  String? _proofOfRegFileName;
  String? _proofOfRegFileSize;

  String? _fundingPayslipFileName;
  String? _fundingPayslipFileSize;

  @override
  void initState() {
    super.initState();
    _loadLoggedInStudentDetails();
  }

  Future<void> _loadLoggedInStudentDetails() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user != null) {
      String name = user.userMetadata?['full_name'] ?? '';
      String studentNum = user.userMetadata?['student_number'] ?? '';
      String email = user.email ?? '';
      String phone = '';

      try {
        final profile = await Supabase.instance.client
            .from('profiles')
            .select()
            .eq('id', user.id)
            .maybeSingle();

        if (profile != null) {
          if (profile['full_name'] != null && profile['full_name'].toString().isNotEmpty) {
            name = profile['full_name'].toString();
          }
          if (profile['student_number'] != null && profile['student_number'].toString().isNotEmpty) {
            studentNum = profile['student_number'].toString();
          }
          if (profile['phone_number'] != null && profile['phone_number'].toString().isNotEmpty) {
            phone = profile['phone_number'].toString();
          }
        }
      } catch (e) {
        print('Error pre-filling application details: $e');
      }

      if (mounted) {
        setState(() {
          _fullNameController.text = name;
          _emailController.text = email;
          _studentNumberController.text = studentNum;
          _phoneController.text = phone;
        });
      }
    }
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return "$bytes B";
    if (bytes < 1024 * 1024) return "${(bytes / 1024).toStringAsFixed(1)} KB";
    return "${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB";
  }

  Future<void> _pickDocument(String docType) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx'],
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        final formattedSize = _formatBytes(file.size);

        setState(() {
          if (docType == 'id') {
            _idCopyFileName = file.name;
            _idCopyFileSize = formattedSize;
          } else if (docType == 'reg') {
            _proofOfRegFileName = file.name;
            _proofOfRegFileSize = formattedSize;
          } else if (docType == 'funding') {
            _fundingPayslipFileName = file.name;
            _fundingPayslipFileSize = formattedSize;
          }
        });

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${file.name} selected ($formattedSize)'),
              backgroundColor: Colors.green,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('File selection error: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  void _removeFile(String docType) {
    setState(() {
      if (docType == 'id') {
        _idCopyFileName = null;
        _idCopyFileSize = null;
      } else if (docType == 'reg') {
        _proofOfRegFileName = null;
        _proofOfRegFileSize = null;
      } else if (docType == 'funding') {
        _fundingPayslipFileName = null;
        _fundingPayslipFileSize = null;
      }
    });
  }

  void _submitApplication() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please log in before submitting an application.')),
      );
      return;
    }

    if (_fullNameController.text.trim().isEmpty || _studentNumberController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your full name and student number.')),
      );
      return;
    }

    if (_idCopyFileName == null || _proofOfRegFileName == null || _fundingPayslipFileName == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select and attach all 3 required documents in Step 4.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 3),
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    final app = ApplicationModel(
      id: '',
      studentId: user.id,
      unitId: widget.unitId,
      fullName: _fullNameController.text.trim(),
      email: _emailController.text.trim(),
      phoneNumber: _phoneController.text.trim(),
      dateOfBirth: _dobController.text.trim(),
      institution: _institutionController.text.trim(),
      studentNumber: _studentNumberController.text.trim(),
      yearOfStudy: _yearController.text.trim(),
      isNsfasFunded: _isNsfasFunded,
      parentName: _parentNameController.text.trim(),
      parentEmail: _parentEmailController.text.trim(),
      parentContact: _parentContactController.text.trim(),
      parentRelationship: _parentRelationshipController.text.trim(),
      status: 'Submitted',
      uploadedDocuments: {
        'ID Copy': '$_idCopyFileName (${_idCopyFileSize ?? ''})',
        'Proof of Registration': '$_proofOfRegFileName (${_proofOfRegFileSize ?? ''})',
        'Funding / Payslip': '$_fundingPayslipFileName (${_fundingPayslipFileSize ?? ''})',
      },
    );

    try {
      final generatedId = await _applicationService.submitApplication(app);

      final submittedAppWithId = ApplicationModel(
        id: generatedId,
        studentId: user.id,
        unitId: widget.unitId,
        fullName: app.fullName,
        email: app.email,
        phoneNumber: app.phoneNumber,
        dateOfBirth: app.dateOfBirth,
        institution: app.institution,
        studentNumber: app.studentNumber,
        yearOfStudy: app.yearOfStudy,
        isNsfasFunded: app.isNsfasFunded,
        parentName: app.parentName,
        parentEmail: app.parentEmail,
        parentContact: app.parentContact,
        parentRelationship: app.parentRelationship,
        status: 'Submitted',
        uploadedDocuments: app.uploadedDocuments,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Application Submitted Successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ApplicationTrackerScreen(initialApplication: submittedAppWithId),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Submission error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Accommodation Application'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
              color: AppTheme.primaryOrange.withOpacity(0.1),
              child: Row(
                children: [
                  const Icon(Icons.assignment, color: AppTheme.primaryOrange, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'Step ${_currentStep + 1} of 4: ${_getStepTitle(_currentStep)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryOrange,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Stepper(
                type: StepperType.horizontal,
                currentStep: _currentStep,
                elevation: 0,
                onStepContinue: () {
                  if (_currentStep < 3) {
                    setState(() => _currentStep += 1);
                  } else {
                    _submitApplication();
                  }
                },
                onStepCancel: () {
                  if (_currentStep > 0) {
                    setState(() => _currentStep -= 1);
                  }
                },
                onStepTapped: (step) => setState(() => _currentStep = step),
                controlsBuilder: (context, details) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 24.0),
                    child: Row(
                      children: [
                        if (_currentStep > 0)
                          Expanded(
                            child: OutlinedButton(
                              onPressed: details.onStepCancel,
                              style: OutlinedButton.styleFrom(
                                minimumSize: const Size(0, 48),
                                side: const BorderSide(color: Colors.grey),
                              ),
                              child: const Text('Back', style: TextStyle(color: Colors.black87)),
                            ),
                          ),
                        if (_currentStep > 0) const SizedBox(width: 12),
                        Expanded(
                          child: CustomButton(
                            text: _currentStep == 3 ? 'Submit Application' : 'Next Step',
                            isLoading: _isLoading,
                            onPressed: details.onStepContinue!,
                          ),
                        ),
                      ],
                    ),
                  );
                },
                steps: [
                  // Step 1: Personal Details
                  Step(
                    title: const Text('1'),
                    subtitle: const Text('Personal'),
                    isActive: _currentStep >= 0,
                    state: _currentStep > 0 ? StepState.complete : StepState.indexed,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Personal Information', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        CustomTextField(label: 'Full Name', controller: _fullNameController, prefixIcon: Icons.person_outline),
                        CustomTextField(label: 'Email Address', controller: _emailController, prefixIcon: Icons.email_outlined),
                        CustomTextField(label: 'Phone Number', controller: _phoneController, prefixIcon: Icons.phone_outlined),
                        CustomTextField(label: 'Date of Birth (YYYY-MM-DD)', controller: _dobController, prefixIcon: Icons.calendar_today_outlined),
                      ],
                    ),
                  ),

                  // Step 2: Academic Details
                  Step(
                    title: const Text('2'),
                    subtitle: const Text('Academic'),
                    isActive: _currentStep >= 1,
                    state: _currentStep > 1 ? StepState.complete : StepState.indexed,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Academic Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        CustomTextField(label: 'Current Institution', controller: _institutionController, prefixIcon: Icons.school_outlined),
                        CustomTextField(label: 'Student Number', controller: _studentNumberController, prefixIcon: Icons.badge_outlined),
                        CustomTextField(label: 'Year of Study', controller: _yearController, prefixIcon: Icons.class_outlined),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade50,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Bursary / Funding Status', style: TextStyle(fontWeight: FontWeight.bold)),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  const Text('NSFAS / Bursary Funded?'),
                                  const Spacer(),
                                  ChoiceChip(
                                    label: const Text('Yes'),
                                    selected: _isNsfasFunded,
                                    selectedColor: AppTheme.primaryOrange,
                                    labelStyle: TextStyle(color: _isNsfasFunded ? Colors.white : Colors.black87),
                                    onSelected: (val) => setState(() => _isNsfasFunded = true),
                                  ),
                                  const SizedBox(width: 8),
                                  ChoiceChip(
                                    label: const Text('No'),
                                    selected: !_isNsfasFunded,
                                    selectedColor: AppTheme.primaryOrange,
                                    labelStyle: TextStyle(color: !_isNsfasFunded ? Colors.white : Colors.black87),
                                    onSelected: (val) => setState(() => _isNsfasFunded = false),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Step 3: Guardian Details
                  Step(
                    title: const Text('3'),
                    subtitle: const Text('Guardian'),
                    isActive: _currentStep >= 2,
                    state: _currentStep > 2 ? StepState.complete : StepState.indexed,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Parent / Guardian Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        CustomTextField(label: 'Parent / Guardian Full Name', controller: _parentNameController, prefixIcon: Icons.person_outline),
                        CustomTextField(label: 'Guardian Email Address', controller: _parentEmailController, prefixIcon: Icons.email_outlined),
                        CustomTextField(label: 'Guardian Contact Number', controller: _parentContactController, prefixIcon: Icons.phone_outlined),
                        CustomTextField(label: 'Relationship (e.g. Mother, Father)', controller: _parentRelationshipController, prefixIcon: Icons.family_restroom_outlined),
                      ],
                    ),
                  ),

                  // Step 4: Documents Upload with FilePicker
                  Step(
                    title: const Text('4'),
                    subtitle: const Text('Documents'),
                    isActive: _currentStep >= 3,
                    state: StepState.indexed,
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Upload Required Documents', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        const Text(
                          'Tap below to browse device storage and attach certified copies of all 3 required files (PDF, PNG, JPG).',
                          style: TextStyle(color: AppTheme.subtextColor, fontSize: 13),
                        ),
                        const SizedBox(height: 16),

                        // Document 1
                        _buildFilePickerCard(
                          title: '1. Certified ID / Passport Copy',
                          description: 'Certified copy of South African ID card or Passport',
                          fileName: _idCopyFileName,
                          fileSize: _idCopyFileSize,
                          onPick: () => _pickDocument('id'),
                          onRemove: () => _removeFile('id'),
                        ),

                        // Document 2
                        _buildFilePickerCard(
                          title: '2. Proof of Registration',
                          description: 'Official university registration letter for current academic year',
                          fileName: _proofOfRegFileName,
                          fileSize: _proofOfRegFileSize,
                          onPick: () => _pickDocument('reg'),
                          onRemove: () => _removeFile('reg'),
                        ),

                        // Document 3
                        _buildFilePickerCard(
                          title: _isNsfasFunded
                              ? '3. NSFAS / Bursary Funding Approval'
                              : '3. Parent / Guardian Payslip (Proof of Income)',
                          description: _isNsfasFunded
                              ? 'Official NSFAS or bursary award confirmation letter'
                              : 'Recent 3 months payslip or bank statement of parent/guardian',
                          fileName: _fundingPayslipFileName,
                          fileSize: _fundingPayslipFileSize,
                          onPick: () => _pickDocument('funding'),
                          onRemove: () => _removeFile('funding'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getStepTitle(int step) {
    switch (step) {
      case 0:
        return 'Personal Details';
      case 1:
        return 'Academic Details';
      case 2:
        return 'Parent / Guardian Details';
      case 3:
        return 'Required Documents Upload';
      default:
        return '';
    }
  }

  Widget _buildFilePickerCard({
    required String title,
    required String description,
    required String? fileName,
    required String? fileSize,
    required VoidCallback onPick,
    required VoidCallback onRemove,
  }) {
    final bool isUploaded = fileName != null;

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isUploaded ? Colors.green.shade400 : Colors.grey.shade300,
          width: isUploaded ? 1.5 : 1,
        ),
      ),
      elevation: 0,
      color: isUploaded ? Colors.green.shade50.withOpacity(0.4) : Colors.grey.shade50,
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  isUploaded ? Icons.check_circle_rounded : Icons.upload_file_rounded,
                  color: isUploaded ? Colors.green : AppTheme.primaryOrange,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
                if (isUploaded)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.green.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text('Attached', style: TextStyle(color: Colors.green, fontSize: 11, fontWeight: FontWeight.bold)),
                  )
                else
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.red.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text('Required', style: TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.bold)),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(description, style: const TextStyle(color: AppTheme.subtextColor, fontSize: 12)),
            const SizedBox(height: 12),
            if (isUploaded)
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.insert_drive_file_outlined, color: AppTheme.primaryOrange, size: 22),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            fileName,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.black87),
                            overflow: TextOverflow.ellipsis,
                          ),
                          if (fileSize != null)
                            Text(
                              fileSize,
                              style: const TextStyle(color: Colors.grey, fontSize: 11),
                            ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                      onPressed: onRemove,
                      tooltip: 'Remove document',
                    ),
                  ],
                ),
              )
            else
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: onPick,
                  icon: const Icon(Icons.folder_open_rounded, size: 18),
                  label: const Text('Choose File from Device'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryOrange,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 44),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
