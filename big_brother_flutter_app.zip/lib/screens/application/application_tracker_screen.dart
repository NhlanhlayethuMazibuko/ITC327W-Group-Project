import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../config/theme.dart';
import '../../services/application_service.dart';
import '../../models/application_model.dart';
import '../../widgets/status_badge.dart';
import '../../widgets/custom_button.dart';
import '../accommodation/available_rooms_screen.dart';

class ApplicationTrackerScreen extends StatefulWidget {
  final ApplicationModel? initialApplication;

  const ApplicationTrackerScreen({Key? key, this.initialApplication}) : super(key: key);

  @override
  State<ApplicationTrackerScreen> createState() => ApplicationTrackerScreenState();
}

class ApplicationTrackerScreenState extends State<ApplicationTrackerScreen> {
  final _applicationService = ApplicationService();
  ApplicationModel? _application;
  bool _isLoading = true;

  Map<String, String> _documentsMap = {};

  @override
  void initState() {
    super.initState();
    if (widget.initialApplication != null) {
      _application = widget.initialApplication;
      _documentsMap = Map<String, String>.from(widget.initialApplication!.uploadedDocuments);
      _isLoading = false;
    } else {
      loadData();
    }
  }

  Future<void> loadData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    final app = await _applicationService.getLatestApplication(user.id);
    if (mounted) {
      setState(() {
        _application = app;
        if (app != null) {
          _documentsMap = Map<String, String>.from(app.uploadedDocuments);
        } else {
          _documentsMap = {};
        }
        _isLoading = false;
      });
    }
  }

  Future<void> _pickAndUploadAdditionalDoc(String docLabel) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx'],
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        setState(() {
          _documentsMap[docLabel] = '${file.name} (Attached)';
        });

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('$docLabel attached: ${file.name}'),
              backgroundColor: Colors.green,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error selecting file: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Application Status Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Refresh Status',
            onPressed: () {
              setState(() => _isLoading = true);
              loadData();
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: loadData,
              child: _application == null
                  ? ListView(
                      padding: const EdgeInsets.all(24.0),
                      children: [
                        const SizedBox(height: 60),
                        Center(
                          child: Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Colors.orange.shade50,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.assignment_outlined, size: 64, color: AppTheme.primaryOrange),
                          ),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'No Active Application',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'You have not submitted an accommodation application yet. Browse our available rooms and apply online today.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppTheme.subtextColor, fontSize: 13),
                        ),
                        const SizedBox(height: 24),
                        CustomButton(
                          text: 'Browse Available Rooms',
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const AvailableRoomsScreen()),
                            );
                          },
                        ),
                      ],
                    )
                  : SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Application Header Card
                          Card(
                            color: AppTheme.primaryOrange.withOpacity(0.08),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(color: AppTheme.primaryOrange.withOpacity(0.3)),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text('Application Reference', style: TextStyle(color: AppTheme.subtextColor, fontSize: 12)),
                                      Text(
                                        _application!.id.isNotEmpty ? _application!.id : 'Submitted',
                                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.primaryOrange),
                                      ),
                                    ],
                                  ),
                                  StatusBadge(status: _application!.status),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),

                          // Application Details Card
                          Card(
                            elevation: 1,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: const [
                                      Icon(Icons.person, color: AppTheme.primaryOrange, size: 20),
                                      SizedBox(width: 8),
                                      Text('Application Details Summary', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                    ],
                                  ),
                                  const Divider(height: 20),
                                  _buildDetailRow('Applicant Name', _application!.fullName),
                                  _buildDetailRow('Student Number', _application!.studentNumber),
                                  _buildDetailRow('Email Address', _application!.email),
                                  _buildDetailRow('Phone Number', _application!.phoneNumber),
                                  _buildDetailRow('Institution', _application!.institution),
                                  _buildDetailRow('Year of Study', _application!.yearOfStudy),
                                  _buildDetailRow('Funding Source', _application!.isNsfasFunded ? 'NSFAS / Bursary' : 'Self / Parent Funded'),
                                  _buildDetailRow('Guardian Name', '${_application!.parentName} (${_application!.parentRelationship})'),
                                  _buildDetailRow('Guardian Contact', _application!.parentContact),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // Attached Documents Section
                          const Text('Attached Documents', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          Card(
                            elevation: 1,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            child: Column(
                              children: [
                                _buildDocumentTile('ID Copy', _documentsMap['ID Copy'] ?? 'Pending'),
                                const Divider(height: 1),
                                _buildDocumentTile('Proof of Registration', _documentsMap['Proof of Registration'] ?? 'Pending'),
                                const Divider(height: 1),
                                _buildDocumentTile('Funding / Payslip', _documentsMap['Funding / Payslip'] ?? 'Pending'),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),

                          // Status Stage Timeline
                          const Text('Application Stage Timeline', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          const Text(
                            'Track real-time progress through the approval pipeline:',
                            style: TextStyle(color: AppTheme.subtextColor, fontSize: 13),
                          ),
                          const SizedBox(height: 16),

                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.grey.shade300),
                            ),
                            child: Column(
                              children: [
                                _buildTimelineItem('1', 'Personal details', 'Submitted & verified', true),
                                _buildTimelineItem('2', 'Academic details', 'Submitted & verified', true),
                                _buildTimelineItem('3', 'Family information', 'Submitted & verified', true),
                                _buildTimelineItem('4', 'Upload documents', 'All 3 documents attached', true),
                                _buildTimelineItem('5', 'Submitted to System', 'Saved to database', true),
                                _buildTimelineItem(
                                  '6',
                                  'Under Review by Landlord',
                                  'Management reviewing particulars',
                                  _application!.status == 'Under Review' || _application!.status == 'Submitted',
                                ),
                                _buildTimelineItem(
                                  '7',
                                  'Approval & Room Assignment',
                                  'Final decision pending',
                                  _application!.status == 'Approved',
                                  isLast: true,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
            ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(label, style: const TextStyle(color: AppTheme.subtextColor, fontSize: 13)),
          ),
          Expanded(
            child: Text(
              value.isNotEmpty ? value : 'N/A',
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Colors.black87),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentTile(String docType, String docStatus) {
    final isUploaded = docStatus.toLowerCase().contains('attached') ||
        docStatus.toLowerCase().contains('uploaded') ||
        docStatus.contains('.pdf') ||
        docStatus.contains('.jpg') ||
        docStatus.contains('.png');

    return ListTile(
      leading: Icon(
        isUploaded ? Icons.insert_drive_file_rounded : Icons.warning_amber_rounded,
        color: isUploaded ? Colors.green : AppTheme.primaryOrange,
      ),
      title: Text(docType, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      subtitle: Text(
        docStatus,
        style: TextStyle(fontSize: 12, color: isUploaded ? Colors.grey.shade700 : Colors.red),
        overflow: TextOverflow.ellipsis,
      ),
      trailing: ElevatedButton.icon(
        onPressed: () => _pickAndUploadAdditionalDoc(docType),
        icon: Icon(isUploaded ? Icons.swap_horiz : Icons.file_upload_outlined, size: 16),
        label: Text(isUploaded ? 'Replace' : 'Upload'),
        style: ElevatedButton.styleFrom(
          backgroundColor: isUploaded ? Colors.grey.shade100 : AppTheme.primaryOrange,
          foregroundColor: isUploaded ? Colors.black87 : Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          minimumSize: const Size(0, 32),
        ),
      ),
    );
  }

  Widget _buildTimelineItem(String step, String title, String subtitle, bool isCompleted, {bool isLast = false}) {
    final Color activeColor = isCompleted ? AppTheme.primaryOrange : Colors.grey.shade300;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            CircleAvatar(
              radius: 14,
              backgroundColor: activeColor,
              child: Text(
                step,
                style: TextStyle(
                  color: isCompleted ? Colors.white : Colors.black54,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            if (!isLast)
              Container(
                height: 30,
                width: 2,
                color: activeColor,
              ),
          ],
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: isCompleted ? FontWeight.bold : FontWeight.normal,
                  color: isCompleted ? AppTheme.textColor : Colors.grey,
                ),
              ),
              Text(
                subtitle,
                style: TextStyle(fontSize: 11, color: isCompleted ? AppTheme.subtextColor : Colors.grey.shade400),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ],
    );
  }
}
