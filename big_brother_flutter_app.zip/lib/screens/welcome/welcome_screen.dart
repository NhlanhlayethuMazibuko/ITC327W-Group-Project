import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // Top Curved Orange Banner matching Screenshot
          ClipPath(
            clipper: BottomWaveClipper(),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 50, bottom: 35),
              color: AppTheme.primaryOrange,
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Image.asset(
                      'assets/images/logo.jpeg',
                      height: 48,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) =>
                          const Icon(Icons.home_work_rounded, color: AppTheme.darkBrown, size: 48),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'BIG BROTHER STUDENT',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.darkBrown,
                      letterSpacing: 0.8,
                    ),
                  ),
                  const Text(
                    'ACCOMMODATIONS',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF8D4000),
                      letterSpacing: 2.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Welcome to Big Brother Student Accommodation',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.textColor,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Find safe, affordable and convenient student accommodation with ease',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 13, color: AppTheme.subtextColor),
                  ),
                  const SizedBox(height: 32),
                  CustomButton(
                    text: 'Log In',
                    icon: Icons.arrow_forward,
                    onPressed: () => Navigator.pushNamed(context, '/login'),
                  ),
                  const SizedBox(height: 14),
                  CustomButton(
                    text: 'Create New Account',
                    isOutlined: true,
                    onPressed: () => Navigator.pushNamed(context, '/register'),
                  ),
                  const SizedBox(height: 36),
                  // Feature Circular Icons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildCircularIcon(Icons.home_outlined),
                      _buildCircularIcon(Icons.description_outlined),
                      _buildCircularIcon(Icons.assignment_turned_in_outlined),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Bottom Footer
          Padding(
            padding: const EdgeInsets.only(bottom: 20.0),
            child: Text(
              'Your home away from home',
              style: TextStyle(
                color: Colors.grey.shade700,
                fontStyle: FontStyle.italic,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircularIcon(IconData icon) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: const BoxDecoration(
        color: Color(0xFFFFE0B2), // Light warm orange fill
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: Colors.black87, size: 24),
    );
  }
}

// Custom Clipper for top curved wave banner
class BottomWaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - 25);
    var firstControlPoint = Offset(size.width / 2, size.height + 20);
    var firstEndPoint = Offset(size.width, size.height - 25);
    path.quadraticBezierTo(
      firstControlPoint.dx,
      firstControlPoint.dy,
      firstEndPoint.dx,
      firstEndPoint.dy,
    );
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
