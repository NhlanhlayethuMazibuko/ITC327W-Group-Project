import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_field.dart';
import 'reset_password_screen.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({Key? key}) : super(key: key);

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailController = TextEditingController();
  final _studentNumberController = TextEditingController();
  bool _isLoading = false;

  void _handleVerifyStudent() async {
    final email = _emailController.text.trim();
    final studentNumber = _studentNumberController.text.trim();

    if (email.isEmpty || !email.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter your registered email address.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (studentNumber.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter your Student Number.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Option 3: Verify student directly in database (No email required)
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('id, full_name, email, student_number')
          .ilike('email', email)
          .eq('student_number', studentNumber)
          .maybeSingle();

      if (profile == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('No student account found matching this Email and Student Number.'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }

      final studentName = profile['full_name']?.toString() ?? 'Student';

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Student identity verified for $studentName!'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );

        // Navigate directly to Reset Password screen with verified credentials
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ResetPasswordScreen(
              email: email,
              studentNumber: studentNumber,
              studentName: studentName,
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Verification error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: const Text('')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 30),
              const Icon(Icons.lock_reset_rounded, size: 64, color: AppTheme.primaryOrange),
              const SizedBox(height: 16),
              const Text(
                'Forgot Your Password?',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Verify your student details below to immediately reset your password without waiting for an email.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppTheme.subtextColor, fontSize: 13, height: 1.4),
              ),
              const SizedBox(height: 28),
              CustomTextField(
                label: 'Registered Email Address',
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                prefixIcon: Icons.email_outlined,
              ),
              const SizedBox(height: 14),
              CustomTextField(
                label: 'Student Number',
                controller: _studentNumberController,
                keyboardType: TextInputType.number,
                prefixIcon: Icons.badge_outlined,
              ),
              const SizedBox(height: 24),
              CustomButton(
                text: 'Verify & Reset Password',
                isLoading: _isLoading,
                onPressed: _handleVerifyStudent,
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Back to Log In', style: TextStyle(color: AppTheme.primaryOrange, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
