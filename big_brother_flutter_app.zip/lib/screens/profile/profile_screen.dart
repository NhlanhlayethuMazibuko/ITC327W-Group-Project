import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../services/auth_service.dart';
import '../auth/reset_password_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _authService = AuthService();
  final _phoneController = TextEditingController();
  final _nameController = TextEditingController();

  bool _isLoading = true;
  bool _isSaving = false;
  bool _isEditing = false;

  String _fullName = 'Student';
  String _email = '';
  String _studentNumber = 'N/A';
  String _phone = 'Not Provided';
  String _memberSince = '2026';

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user != null) {
      String name = user.userMetadata?['full_name'] ?? '';
      String studentNum = user.userMetadata?['student_number'] ?? '';
      String userEmail = user.email ?? '';

      try {
        final profile = await Supabase.instance.client
            .from('profiles')
            .select()
            .eq('id', user.id)
            .maybeSingle();

        if (profile != null) {
          if (profile['full_name'] != null && profile['full_name'].toString().isNotEmpty) {
            name = profile['full_name'].toString();
          }
          if (profile['student_number'] != null && profile['student_number'].toString().isNotEmpty) {
            studentNum = profile['student_number'].toString();
          }
          if (profile['phone_number'] != null && profile['phone_number'].toString().isNotEmpty) {
            _phone = profile['phone_number'].toString();
          }
          if (profile['created_at'] != null) {
            final dt = DateTime.parse(profile['created_at'].toString());
            _memberSince = "${dt.year}";
          }
        }
      } catch (e) {
        print('Error fetching profile: $e');
      }

      if (name.isEmpty && userEmail.contains('@')) {
        name = userEmail.split('@').first;
      }

      if (mounted) {
        setState(() {
          _fullName = name.isNotEmpty ? name : 'Student';
          _email = userEmail;
          _studentNumber = studentNum.isNotEmpty ? studentNum : 'N/A';
          _nameController.text = _fullName;
          _phoneController.text = _phone != 'Not Provided' ? _phone : '';
          _isLoading = false;
        });
      }
    } else {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _saveProfileChanges() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    setState(() => _isSaving = true);

    final newName = _nameController.text.trim();
    final newPhone = _phoneController.text.trim();

    try {
      await Supabase.instance.client.from('profiles').upsert({
        'id': user.id,
        'full_name': newName,
        'email': _email,
        'student_number': _studentNumber,
        'phone_number': newPhone,
      });

      if (mounted) {
        setState(() {
          _fullName = newName;
          _phone = newPhone.isNotEmpty ? newPhone : 'Not Provided';
          _isEditing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated successfully!'), backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error updating profile: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  String _getInitials(String name) {
    if (name.isEmpty) return 'S';
    final parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return parts[0][0].toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 8),

                  // Brand Logo Header Banner
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryOrange.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.primaryOrange.withOpacity(0.2)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/images/logo.jpeg',
                          height: 36,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) =>
                              const Icon(Icons.home_work_rounded, color: AppTheme.primaryOrange, size: 32),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'BIG BROTHER ACCOMMODATION',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryOrange,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Avatar Circle with Initials
                  CircleAvatar(
                    radius: 42,
                    backgroundColor: AppTheme.primaryOrange,
                    child: Text(
                      _getInitials(_fullName),
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Student Name & Badge
                  Text(
                    _fullName,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.textColor),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'Registered Student • Member since $_memberSince',
                      style: const TextStyle(fontSize: 12, color: AppTheme.subtextColor, fontWeight: FontWeight.w500),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Student Details Card
                  Card(
                    elevation: 1,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: const Icon(Icons.person_outline, color: AppTheme.primaryOrange),
                            title: const Text('Full Name', style: TextStyle(color: Colors.grey, fontSize: 12)),
                            subtitle: _isEditing
                                ? TextField(
                                    controller: _nameController,
                                    decoration: const InputDecoration(isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 6)),
                                  )
                                : Text(_fullName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                          ),
                          const Divider(height: 1),
                          ListTile(
                            leading: const Icon(Icons.email_outlined, color: AppTheme.primaryOrange),
                            title: const Text('Email Address', style: TextStyle(color: Colors.grey, fontSize: 12)),
                            subtitle: Text(_email, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                          ),
                          const Divider(height: 1),
                          ListTile(
                            leading: const Icon(Icons.badge_outlined, color: AppTheme.primaryOrange),
                            title: const Text('Student Number', style: TextStyle(color: Colors.grey, fontSize: 12)),
                            subtitle: Text(_studentNumber, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                          ),
                          const Divider(height: 1),
                          ListTile(
                            leading: const Icon(Icons.phone_outlined, color: AppTheme.primaryOrange),
                            title: const Text('Phone Number', style: TextStyle(color: Colors.grey, fontSize: 12)),
                            subtitle: _isEditing
                                ? TextField(
                                    controller: _phoneController,
                                    keyboardType: TextInputType.phone,
                                    decoration: const InputDecoration(
                                      hintText: 'Enter phone number',
                                      isDense: true,
                                      contentPadding: EdgeInsets.symmetric(vertical: 6),
                                    ),
                                  )
                                : Text(_phone, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Edit Profile or Save Button
                  if (_isEditing)
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => setState(() => _isEditing = false),
                            child: const Text('Cancel'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: CustomButton(
                            text: 'Save Details',
                            isLoading: _isSaving,
                            onPressed: _saveProfileChanges,
                          ),
                        ),
                      ],
                    )
                  else
                    OutlinedButton.icon(
                      onPressed: () => setState(() => _isEditing = true),
                      icon: const Icon(Icons.edit_outlined, size: 18),
                      label: const Text('Edit Profile Details'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppTheme.primaryOrange,
                        side: const BorderSide(color: AppTheme.primaryOrange),
                        minimumSize: const Size(double.infinity, 44),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                      ),
                    ),
                  const SizedBox(height: 16),

                  // Change Password Button
                  CustomButton(
                    text: 'Change Password',
                    isOutlined: true,
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ResetPasswordScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 12),

                  // Log Out Button
                  CustomButton(
                    text: 'Log Out',
                    onPressed: () async {
                      await _authService.signOut();
                      if (context.mounted) {
                        Navigator.pushNamedAndRemoveUntil(context, '/welcome', (route) => false);
                      }
                    },
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
    );
  }
}
