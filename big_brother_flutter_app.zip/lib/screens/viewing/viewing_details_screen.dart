import 'package:flutter/material.dart';
import '../../models/viewing_request_model.dart';
import '../../config/theme.dart';
import '../../widgets/status_badge.dart';

class ViewingDetailsScreen extends StatelessWidget {
  final ViewingRequestModel viewing;

  const ViewingDetailsScreen({Key? key, required this.viewing}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Viewing Details')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 180,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                child: Icon(Icons.apartment_rounded, size: 60, color: Colors.grey),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(viewing.unitTitle, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                StatusBadge(status: viewing.status),
              ],
            ),
            const SizedBox(height: 8),
            Text(viewing.location, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.calendar_today, color: AppTheme.primaryRed),
                        const SizedBox(width: 12),
                        Text(viewing.preferredDate, style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        const Icon(Icons.access_time, color: AppTheme.primaryRed),
                        const SizedBox(width: 12),
                        Text(viewing.timeSlot, style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Awaiting Confirmation / Confirmed:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            const Text(
              'Your viewing request has been submitted. We will notify you once management confirms your appointment.',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
