import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../services/viewing_service.dart';
import 'scheduled_viewings_screen.dart';

class RequestViewingScreen extends StatefulWidget {
  final String unitTitle;

  const RequestViewingScreen({Key? key, required this.unitTitle}) : super(key: key);

  @override
  State<RequestViewingScreen> createState() => _RequestViewingScreenState();
}

class _RequestViewingScreenState extends State<RequestViewingScreen> {
  final _viewingService = ViewingService();
  
  DateTime _selectedDate = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _selectedTime = const TimeOfDay(hour: 10, minute: 0);

  final List<String> _quickTimeSlots = [
    '09:00 AM',
    '10:30 AM',
    '12:00 PM',
    '02:00 PM',
    '03:30 PM',
    '05:00 PM',
  ];

  String _customTimeString = '10:00 AM';
  bool _useQuickSlot = true;
  String _selectedQuickSlot = '10:30 AM';

  bool _isLoading = false;
  bool _isSubmitted = false;
  String _refCode = '';

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 90)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppTheme.primaryOrange,
              onPrimary: Colors.white,
              onSurface: Colors.black87,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _pickTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppTheme.primaryOrange,
              onPrimary: Colors.white,
              onSurface: Colors.black87,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      final now = DateTime.now();
      final dt = DateTime(now.year, now.month, now.day, picked.hour, picked.minute);
      final formattedTime = DateFormat('hh:mm a').format(dt);

      setState(() {
        _selectedTime = picked;
        _customTimeString = formattedTime;
        _useQuickSlot = false;
      });
    }
  }

  void _submitViewing() async {
    setState(() => _isLoading = true);
    
    final formattedDateStr = DateFormat('EEEE, d MMMM yyyy').format(_selectedDate);
    final finalTimeStr = _useQuickSlot ? _selectedQuickSlot : _customTimeString;

    try {
      final req = await _viewingService.requestViewing(
        unitTitle: widget.unitTitle,
        preferredDate: formattedDateStr,
        timeSlot: finalTimeStr,
      );
      if (mounted) {
        setState(() {
          _isSubmitted = true;
          _refCode = req.referenceCode;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error submitting request: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final formattedDateStr = DateFormat('EEEE, d MMMM yyyy').format(_selectedDate);
    final finalTimeStr = _useQuickSlot ? _selectedQuickSlot : _customTimeString;

    if (_isSubmitted) {
      return Scaffold(
        appBar: AppBar(title: const Text('Viewing Confirmation')),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_circle_rounded, size: 70, color: Colors.green),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Viewing Request Submitted!',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Your viewing booking has been received. Our property agent will contact you shortly.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.subtextColor, fontSize: 13),
                  ),
                  const SizedBox(height: 24),

                  // Reference Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryOrange.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.primaryOrange.withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        const Text('Booking Reference Code', style: TextStyle(color: AppTheme.subtextColor, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text(
                          _refCode,
                          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.primaryOrange),
                        ),
                        const Divider(height: 24),
                        _buildSummaryRow(Icons.apartment_rounded, 'Unit', widget.unitTitle),
                        const SizedBox(height: 8),
                        _buildSummaryRow(Icons.calendar_today_rounded, 'Date', formattedDateStr),
                        const SizedBox(height: 8),
                        _buildSummaryRow(Icons.access_time_rounded, 'Time', finalTimeStr),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),

                  CustomButton(
                    text: 'View Scheduled Viewings',
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (_) => const ScheduledViewingsScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 12),
                  CustomButton(
                    text: 'Back to Home',
                    isOutlined: true,
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Schedule Viewing')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Room Banner
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.apartment_rounded, color: AppTheme.primaryOrange, size: 32),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Selected Accommodation:', style: TextStyle(color: AppTheme.subtextColor, fontSize: 11)),
                          Text(
                            widget.unitTitle,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Step 1: Pick Date
              const Text('1. Select Preferred Date', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Pick a date when you are available for an in-person room inspection:', style: TextStyle(color: AppTheme.subtextColor, fontSize: 12)),
              const SizedBox(height: 10),
              Card(
                elevation: 0,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: AppTheme.primaryOrange, width: 1.5),
                ),
                child: ListTile(
                  leading: const Icon(Icons.calendar_today_rounded, color: AppTheme.primaryOrange),
                  title: Text(
                    formattedDateStr,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  subtitle: const Text('Tap to open date calendar', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  trailing: const Icon(Icons.arrow_drop_down_circle_outlined, color: AppTheme.primaryOrange),
                  onTap: () => _pickDate(context),
                ),
              ),
              const SizedBox(height: 24),

              // Step 2: Pick Time Slot
              const Text('2. Select Preferred Time', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Choose from available appointment slots or select a custom time:', style: TextStyle(color: AppTheme.subtextColor, fontSize: 12)),
              const SizedBox(height: 12),

              // Quick Time Slot Chips
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _quickTimeSlots.map((slot) {
                  final isSelected = _useQuickSlot && _selectedQuickSlot == slot;
                  return ChoiceChip(
                    label: Text(slot),
                    selected: isSelected,
                    selectedColor: AppTheme.primaryOrange,
                    backgroundColor: Colors.grey.shade100,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.black87,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                    onSelected: (selected) {
                      if (selected) {
                        setState(() {
                          _selectedQuickSlot = slot;
                          _useQuickSlot = true;
                        });
                      }
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 14),

              // Custom Time Picker Option
              Card(
                elevation: 0,
                color: !_useQuickSlot ? Colors.orange.shade50 : Colors.grey.shade50,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                    color: !_useQuickSlot ? AppTheme.primaryOrange : Colors.grey.shade300,
                  ),
                ),
                child: ListTile(
                  leading: Icon(Icons.access_time_rounded, color: !_useQuickSlot ? AppTheme.primaryOrange : Colors.grey),
                  title: Text(
                    !_useQuickSlot ? 'Custom Time: $_customTimeString' : 'Select Custom Time Slot',
                    style: TextStyle(
                      fontWeight: !_useQuickSlot ? FontWeight.bold : FontWeight.normal,
                      fontSize: 14,
                    ),
                  ),
                  subtitle: const Text('Tap to choose exact clock time', style: TextStyle(fontSize: 11)),
                  trailing: const Icon(Icons.edit_calendar, size: 20),
                  onTap: () => _pickTime(context),
                ),
              ),
              const SizedBox(height: 32),

              // Confirm Button
              CustomButton(
                text: 'Confirm Viewing Request',
                isLoading: _isLoading,
                onPressed: _submitViewing,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSummaryRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppTheme.primaryOrange),
        const SizedBox(width: 8),
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        Expanded(
          child: Text(value, style: const TextStyle(fontSize: 13), overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }
}
