import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../services/viewing_service.dart';
import '../../models/viewing_request_model.dart';
import '../../widgets/status_badge.dart';
import '../../widgets/custom_button.dart';
import '../accommodation/available_rooms_screen.dart';
import 'viewing_details_screen.dart';

class ScheduledViewingsScreen extends StatefulWidget {
  const ScheduledViewingsScreen({Key? key}) : super(key: key);

  @override
  State<ScheduledViewingsScreen> createState() => _ScheduledViewingsScreenState();
}

class _ScheduledViewingsScreenState extends State<ScheduledViewingsScreen> {
  final _viewingService = ViewingService();
  List<ViewingRequestModel> _viewings = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadViewings();
  }

  void _loadViewings() async {
    final res = await _viewingService.getScheduledViewings();
    if (mounted) {
      setState(() {
        _viewings = res;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Scheduled Viewings')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _viewings.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.orange.shade50,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.calendar_today_outlined, size: 64, color: AppTheme.primaryOrange),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'No Scheduled Viewings',
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'You have not booked any accommodation inspection visits yet. Browse our rooms and select a date and time slot to view in person.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppTheme.subtextColor, fontSize: 13),
                        ),
                        const SizedBox(height: 24),
                        CustomButton(
                          text: 'Browse Rooms & Schedule',
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const AvailableRoomsScreen()),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _viewings.length,
                  itemBuilder: (context, index) {
                    final item = _viewings[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      elevation: 1,
                      child: ListTile(
                        leading: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryOrange.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.calendar_month_rounded, color: AppTheme.primaryOrange),
                        ),
                        title: Text(item.unitTitle, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4.0),
                          child: Text(
                            'Ref: ${item.referenceCode}\nDate: ${item.preferredDate} • ${item.timeSlot}',
                            style: const TextStyle(fontSize: 12, height: 1.3),
                          ),
                        ),
                        trailing: StatusBadge(status: item.status),
                        isThreeLine: true,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => ViewingDetailsScreen(viewing: item)),
                          );
                        },
                      ),
                    );
                  },
                ),
    );
  }
}
