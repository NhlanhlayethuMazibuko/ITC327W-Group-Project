import 'package:flutter/material.dart';
import '../../models/maintenance_request_model.dart';
import '../../widgets/status_badge.dart';

class MaintenanceDetailsScreen extends StatelessWidget {
  final MaintenanceRequestModel request;

  const MaintenanceDetailsScreen({Key? key, required this.request}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Maintenance Report')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Request ID: ${request.referenceCode}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                StatusBadge(status: request.status),
              ],
            ),
            const SizedBox(height: 20),
            _buildDetailRow('Category', request.category),
            _buildDetailRow('Priority', request.priority),
            _buildDetailRow('Created Date', request.createdAt),
            const SizedBox(height: 16),
            const Text('Description', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 6),
            Text(request.description, style: const TextStyle(color: Colors.black87)),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
