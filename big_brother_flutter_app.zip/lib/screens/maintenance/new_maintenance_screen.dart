import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_field.dart';
import '../../services/maintenance_service.dart';

class NewMaintenanceScreen extends StatefulWidget {
  const NewMaintenanceScreen({Key? key}) : super(key: key);

  @override
  State<NewMaintenanceScreen> createState() => _NewMaintenanceScreenState();
}

class _NewMaintenanceScreenState extends State<NewMaintenanceScreen> {
  final _maintenanceService = MaintenanceService();
  String _category = 'Plumbing';
  String _priority = 'High';
  final _descriptionController = TextEditingController();

  String? _pickedImageName;
  String? _pickedImageSize;
  bool _isLoading = false;
  bool _isSubmitted = false;
  String _refCode = '';

  String _formatBytes(int bytes) {
    if (bytes < 1024) return "$bytes B";
    if (bytes < 1024 * 1024) return "${(bytes / 1024).toStringAsFixed(1)} KB";
    return "${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB";
  }

  Future<void> _pickImage() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png'],
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        setState(() {
          _pickedImageName = file.name;
          _pickedImageSize = _formatBytes(file.size);
        });

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Image attached: ${file.name}'),
              backgroundColor: Colors.green,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error choosing image: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  void _removeImage() {
    setState(() {
      _pickedImageName = null;
      _pickedImageSize = null;
    });
  }

  void _submit() async {
    final description = _descriptionController.text.trim();
    if (description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please describe the maintenance issue.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final req = await _maintenanceService.submitRequest(
        category: _category,
        priority: _priority,
        description: description,
        photoUrl: _pickedImageName != null ? '$_pickedImageName ($_pickedImageSize)' : null,
      );

      if (mounted) {
        setState(() {
          _isSubmitted = true;
          _refCode = req.referenceCode;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error submitting request: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isSubmitted) {
      return Scaffold(
        appBar: AppBar(title: const Text('Request Submitted')),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_circle_rounded, size: 70, color: Colors.green),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Maintenance Request Logged!',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Your maintenance request has been forwarded to building management.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppTheme.subtextColor, fontSize: 13),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryOrange.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.primaryOrange.withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        const Text('Maintenance Reference Code', style: TextStyle(color: AppTheme.subtextColor, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text(
                          _refCode,
                          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.primaryOrange),
                        ),
                        const Divider(height: 24),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Category:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                            Text(_category, style: const TextStyle(fontSize: 13)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Priority:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                            Text('$_priority Priority', style: const TextStyle(fontSize: 13)),
                          ],
                        ),
                        if (_pickedImageName != null) ...[
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Photo:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                              Expanded(
                                child: Text(
                                  _pickedImageName!,
                                  textAlign: TextAlign.right,
                                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),
                  CustomButton(
                    text: 'Back to Maintenance List',
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('New Maintenance Request')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Category
              const Text('Issue Category', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _category,
                    isExpanded: true,
                    items: ['Plumbing', 'Electrical', 'Furniture', 'Appliance', 'Security / Lock', 'Other']
                        .map((e) => DropdownMenuItem(value: e, child: Text(e, style: const TextStyle(fontWeight: FontWeight.w500))))
                        .toList(),
                    onChanged: (val) => setState(() => _category = val!),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Priority
              const Text('Priority Level', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 8),
              Row(
                children: ['Low', 'Medium', 'High'].map((p) {
                  final isSelected = _priority == p;
                  Color chipColor = Colors.grey.shade200;
                  Color activeTextColor = Colors.white;
                  Color activeBgColor = AppTheme.primaryOrange;

                  if (p == 'High') activeBgColor = Colors.red.shade700;
                  if (p == 'Medium') activeBgColor = Colors.orange.shade800;
                  if (p == 'Low') activeBgColor = Colors.blue.shade700;

                  return Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: ChoiceChip(
                      label: Text(p),
                      selected: isSelected,
                      selectedColor: activeBgColor,
                      backgroundColor: chipColor,
                      labelStyle: TextStyle(
                        color: isSelected ? activeTextColor : Colors.black87,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                      onSelected: (selected) {
                        if (selected) setState(() => _priority = p);
                      },
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),

              // Description
              const Text('Description of Issue', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 8),
              CustomTextField(
                label: 'Describe what needs fixing...',
                controller: _descriptionController,
                maxLines: 4,
              ),
              const SizedBox(height: 20),

              // Photo Upload Section with FilePicker
              const Text('Photo of the Issue (Optional)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 4),
              const Text(
                'Attach an image to help the maintenance team assess the problem quickly:',
                style: TextStyle(color: AppTheme.subtextColor, fontSize: 12),
              ),
              const SizedBox(height: 10),

              if (_pickedImageName != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.shade400),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.image, color: Colors.green, size: 28),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _pickedImageName!,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                              overflow: TextOverflow.ellipsis,
                            ),
                            if (_pickedImageSize != null)
                              Text(
                                _pickedImageSize!,
                                style: const TextStyle(fontSize: 11, color: Colors.grey),
                              ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.red),
                        onPressed: _removeImage,
                        tooltip: 'Remove photo',
                      ),
                    ],
                  ),
                )
              else
                InkWell(
                  onTap: _pickImage,
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    height: 120,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      border: Border.all(color: Colors.grey.shade300, style: BorderStyle.solid),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.add_a_photo_outlined, color: AppTheme.primaryOrange, size: 36),
                        SizedBox(height: 8),
                        Text(
                          'Tap to choose image from device',
                          style: TextStyle(color: AppTheme.primaryOrange, fontWeight: FontWeight.bold, fontSize: 13),
                        ),
                        SizedBox(height: 2),
                        Text('Supports JPG, PNG, JPEG', style: TextStyle(color: Colors.grey, fontSize: 11)),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 32),

              // Submit Button
              CustomButton(
                text: 'Submit Request',
                isLoading: _isLoading,
                onPressed: _submit,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
