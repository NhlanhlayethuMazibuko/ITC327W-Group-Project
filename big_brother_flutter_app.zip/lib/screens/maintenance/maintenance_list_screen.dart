import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../services/maintenance_service.dart';
import '../../models/maintenance_request_model.dart';
import '../../widgets/status_badge.dart';
import '../../widgets/custom_button.dart';
import 'new_maintenance_screen.dart';
import 'maintenance_details_screen.dart';

class MaintenanceListScreen extends StatefulWidget {
  const MaintenanceListScreen({Key? key}) : super(key: key);

  @override
  State<MaintenanceListScreen> createState() => _MaintenanceListScreenState();
}

class _MaintenanceListScreenState extends State<MaintenanceListScreen> {
  final _maintenanceService = MaintenanceService();
  List<MaintenanceRequestModel> _requests = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  void _loadRequests() async {
    final res = await _maintenanceService.getRequests();
    if (mounted) {
      setState(() {
        _requests = res;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Maintenance Requests')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Expanded(
                    child: _requests.isEmpty
                        ? Center(
                            child: Padding(
                              padding: const EdgeInsets.all(24.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(20),
                                    decoration: BoxDecoration(
                                      color: Colors.orange.shade50,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.build_outlined, size: 64, color: AppTheme.primaryOrange),
                                  ),
                                  const SizedBox(height: 20),
                                  const Text(
                                    'No Maintenance Requests',
                                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 8),
                                  const Text(
                                    'You currently have no open or past maintenance requests. Tap below if anything in your room requires inspection or repair.',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(color: AppTheme.subtextColor, fontSize: 13),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _requests.length,
                            itemBuilder: (context, index) {
                              final item = _requests[index];
                              return Card(
                                margin: const EdgeInsets.only(bottom: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                elevation: 1,
                                child: ListTile(
                                  leading: Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: AppTheme.primaryOrange.withOpacity(0.1),
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.handyman_outlined, color: AppTheme.primaryOrange),
                                  ),
                                  title: Text(
                                    '${item.category} (${item.priority} Priority)',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  subtitle: Padding(
                                    padding: const EdgeInsets.only(top: 4.0),
                                    child: Text(
                                      'Ref: ${item.referenceCode}\nIssue: ${item.description}',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 12, height: 1.3),
                                    ),
                                  ),
                                  trailing: StatusBadge(status: item.status),
                                  isThreeLine: true,
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (_) => MaintenanceDetailsScreen(request: item)),
                                    );
                                  },
                                ),
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 12),
                  CustomButton(
                    text: 'New Maintenance Request',
                    icon: Icons.add,
                    onPressed: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const NewMaintenanceScreen()),
                      );
                      _loadRequests();
                    },
                  ),
                ],
              ),
            ),
    );
  }
}
