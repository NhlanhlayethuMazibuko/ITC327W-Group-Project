import 'package:flutter/material.dart';
import '../../services/review_service.dart';
import '../../models/review_model.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_field.dart';

class ReviewsScreen extends StatefulWidget {
  const ReviewsScreen({Key? key}) : super(key: key);

  @override
  State<ReviewsScreen> createState() => _ReviewsScreenState();
}

class _ReviewsScreenState extends State<ReviewsScreen> {
  final _reviewService = ReviewService();
  int _selectedRating = 5;
  final _commentController = TextEditingController();
  List<ReviewModel> _reviews = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadReviews();
  }

  void _loadReviews() async {
    final list = await _reviewService.getReviews();
    if (mounted) {
      setState(() {
        _reviews = list;
        _isLoading = false;
      });
    }
  }

  void _submitReview() async {
    await _reviewService.submitReview(
      rating: _selectedRating,
      comment: _commentController.text,
    );
    _commentController.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Feedback submitted successfully')),
    );
    _loadReviews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Review & Feedback')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Rate your experience', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            Row(
              children: List.generate(
                5,
                (index) => IconButton(
                  icon: Icon(
                    index < _selectedRating ? Icons.star : Icons.star_border,
                    color: Colors.amber,
                    size: 32,
                  ),
                  onPressed: () => setState(() => _selectedRating = index + 1),
                ),
              ),
            ),
            const SizedBox(height: 12),
            CustomTextField(
              label: 'Your comment',
              controller: _commentController,
              hint: 'Write your feedback here ...',
              maxLines: 3,
            ),
            const SizedBox(height: 12),
            CustomButton(text: 'Submit Review', onPressed: _submitReview),
            const SizedBox(height: 32),
            const Text('Previous Reviews', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 12),
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _reviews.length,
                    itemBuilder: (context, index) {
                      final r = _reviews[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(r.studentName, style: const TextStyle(fontWeight: FontWeight.bold)),
                                  Row(
                                    children: List.generate(
                                      r.rating,
                                      (_) => const Icon(Icons.star, color: Colors.amber, size: 16),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(r.comment, style: const TextStyle(color: Colors.black87)),
                              const SizedBox(height: 4),
                              Text(r.date, style: const TextStyle(color: Colors.grey, fontSize: 11)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }
}
