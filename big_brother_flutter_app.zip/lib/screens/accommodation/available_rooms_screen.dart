import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../models/accommodation_unit.dart';
import '../../services/accommodation_service.dart';
import '../../widgets/unit_card.dart';
import 'unit_details_screen.dart';

class AvailableRoomsScreen extends StatefulWidget {
  const AvailableRoomsScreen({Key? key}) : super(key: key);

  @override
  State<AvailableRoomsScreen> createState() => _AvailableRoomsScreenState();
}

class _AvailableRoomsScreenState extends State<AvailableRoomsScreen> {
  final _accommodationService = AccommodationService();
  final _searchController = TextEditingController();

  List<AccommodationUnit> _allUnits = [];
  List<AccommodationUnit> _filteredUnits = [];
  bool _isLoading = true;
  String _selectedCategory = 'All';

  final List<String> _categories = ['All', 'Single Room', '1-Bedroom', '2-Bedroom'];

  @override
  void initState() {
    super.initState();
    _loadUnits();
  }

  void _loadUnits() async {
    final units = await _accommodationService.getAvailableUnits();
    if (mounted) {
      setState(() {
        _allUnits = units;
        _filteredUnits = units;
        _isLoading = false;
      });
    }
  }

  void _applyFilter() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredUnits = _allUnits.where((unit) {
        final matchesQuery = query.isEmpty ||
            unit.title.toLowerCase().contains(query) ||
            unit.type.toLowerCase().contains(query) ||
            unit.location.toLowerCase().contains(query);

        final matchesCategory = _selectedCategory == 'All' ||
            unit.type.toLowerCase().contains(_selectedCategory.toLowerCase()) ||
            unit.title.toLowerCase().contains(_selectedCategory.toLowerCase());

        return matchesQuery && matchesCategory;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Accommodation'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Choose the perfect room to suit your lifestyle and budget',
              style: TextStyle(color: AppTheme.subtextColor, fontSize: 14),
            ),
            const SizedBox(height: 14),

            // Search Bar
            TextField(
              controller: _searchController,
              onChanged: (_) => _applyFilter(),
              decoration: InputDecoration(
                hintText: 'Search by room title or area...',
                prefixIcon: const Icon(Icons.search, color: AppTheme.primaryOrange),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _applyFilter();
                        },
                      )
                    : null,
                fillColor: Colors.grey.shade100,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 14),

            // Filter Chips
            SizedBox(
              height: 38,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final cat = _categories[index];
                  final isSelected = _selectedCategory == cat;
                  return ChoiceChip(
                    label: Text(cat),
                    selected: isSelected,
                    selectedColor: AppTheme.primaryOrange,
                    backgroundColor: Colors.grey.shade100,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.black87,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                    onSelected: (selected) {
                      if (selected) {
                        setState(() => _selectedCategory = cat);
                        _applyFilter();
                      }
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 16),

            // Room Listings
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _filteredUnits.isEmpty
                      ? const Center(
                          child: Text('No available rooms match your criteria.', style: TextStyle(color: Colors.grey)),
                        )
                      : ListView.builder(
                          itemCount: _filteredUnits.length,
                          itemBuilder: (context, index) {
                            final unit = _filteredUnits[index];
                            return UnitCard(
                              unit: unit,
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => UnitDetailsScreen(unit: unit),
                                  ),
                                );
                              },
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
