import 'package:flutter/material.dart';
import '../../models/accommodation_unit.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/unit_image.dart';
import '../application/application_stepper_screen.dart';
import '../viewing/request_viewing_screen.dart';

class UnitDetailsScreen extends StatelessWidget {
  final AccommodationUnit unit;

  const UnitDetailsScreen({Key? key, required this.unit}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Unit details')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Image Box
            UnitImage(
              imageUrl: unit.imageUrl,
              height: 200,
              borderRadius: 12,
              iconSize: 70,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  unit.title,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    unit.status,
                    style: TextStyle(color: Colors.green.shade800, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'R${unit.pricePerMonth.toStringAsFixed(0)}/Month',
              style: const TextStyle(fontSize: 18, color: AppTheme.primaryRed, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            // Amenities Tags
            const Text('Facilities & Amenities', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildAmenityChip(Icons.wifi, 'Wi-Fi'),
                _buildAmenityChip(Icons.local_laundry_service, 'Laundry'),
                _buildAmenityChip(Icons.security, 'Security'),
                _buildAmenityChip(Icons.directions_bus, 'Shuttle'),
              ],
            ),
            const SizedBox(height: 20),

            // Description
            const Text('Description', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(
              unit.description,
              style: const TextStyle(color: Colors.black87, height: 1.4),
            ),
            const SizedBox(height: 20),

            // Furniture
            const Text('Furniture', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(unit.furnitureDetails, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 32),

            // Buttons
            CustomButton(
              text: 'Apply Now',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ApplicationStepperScreen(unitId: unit.id)),
                );
              },
            ),
            const SizedBox(height: 12),
            CustomButton(
              text: 'Schedule Viewing',
              isOutlined: true,
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => RequestViewingScreen(unitTitle: unit.title)),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAmenityChip(IconData icon, String label) {
    return Column(
      children: [
        CircleAvatar(
          backgroundColor: Colors.grey.shade100,
          radius: 20,
          child: Icon(icon, color: AppTheme.primaryOrange, size: 20),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
      ],
    );
  }
}
