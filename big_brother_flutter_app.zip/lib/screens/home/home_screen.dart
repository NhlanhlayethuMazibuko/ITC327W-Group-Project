import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../config/theme.dart';
import '../../models/accommodation_unit.dart';
import '../../services/accommodation_service.dart';
import '../../widgets/unit_card.dart';
import '../accommodation/available_rooms_screen.dart';
import '../accommodation/unit_details_screen.dart';
import '../application/application_tracker_screen.dart';
import '../viewing/scheduled_viewings_screen.dart';
import '../payment/payment_screen.dart';
import '../reviews/reviews_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _accommodationService = AccommodationService();
  final _searchController = TextEditingController();
  
  List<AccommodationUnit> _allUnits = [];
  List<AccommodationUnit> _filteredUnits = [];
  bool _isLoading = true;
  String _userName = 'Student';

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
    _loadUnits();
  }

  void _loadUserProfile() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user != null) {
      // 1. Try metadata from sign up
      final metaName = user.userMetadata?['full_name'];
      if (metaName != null && metaName.toString().trim().isNotEmpty) {
        if (mounted) setState(() => _userName = metaName.toString().trim());
        return;
      }
      
      // 2. Query public.profiles table
      try {
        final profile = await Supabase.instance.client
            .from('profiles')
            .select('full_name')
            .eq('id', user.id)
            .maybeSingle();
            
        if (profile != null && profile['full_name'] != null && profile['full_name'].toString().isNotEmpty) {
          if (mounted) setState(() => _userName = profile['full_name'].toString().trim());
          return;
        }
      } catch (e) {
        print('Error fetching profile name: $e');
      }

      // 3. Fallback to email prefix
      if (user.email != null && user.email!.contains('@')) {
        final emailPrefix = user.email!.split('@').first;
        if (mounted) setState(() => _userName = emailPrefix);
      }
    }
  }

  void _loadUnits() async {
    final units = await _accommodationService.getAvailableUnits();
    if (mounted) {
      setState(() {
        _allUnits = units;
        _filteredUnits = units;
        _isLoading = false;
      });
    }
  }

  void _onSearchChanged(String query) {
    if (query.isEmpty) {
      setState(() => _filteredUnits = _allUnits);
    } else {
      setState(() {
        _filteredUnits = _allUnits.where((unit) {
          final titleMatch = unit.title.toLowerCase().contains(query.toLowerCase());
          final typeMatch = unit.type.toLowerCase().contains(query.toLowerCase());
          final locationMatch = unit.location.toLowerCase().contains(query.toLowerCase());
          return titleMatch || typeMatch || locationMatch;
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Dynamic Greeting for Logged In Existing User
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Hello, $_userName 👋',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.textColor),
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    'Welcome back to Big Brother Accommodations',
                    style: TextStyle(fontSize: 13, color: AppTheme.subtextColor),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Search Bar
          TextField(
            controller: _searchController,
            onChanged: _onSearchChanged,
            decoration: InputDecoration(
              hintText: 'Search for rooms, apartments or locations...',
              prefixIcon: const Icon(Icons.search, color: AppTheme.primaryOrange),
              suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        _onSearchChanged('');
                      },
                    )
                  : null,
              fillColor: Colors.grey.shade100,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 20),

          // Quick Actions Grid
          const Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildQuickActionCard(
                  context,
                  icon: Icons.domain_rounded,
                  label: 'View\nAccommodation',
                  color: const Color(0xFFFFF3E0),
                  iconColor: AppTheme.primaryOrange,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AvailableRoomsScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildQuickActionCard(
                  context,
                  icon: Icons.folder_shared_outlined,
                  label: 'My\nApplications',
                  color: const Color(0xFFE8F5E9),
                  iconColor: Colors.green.shade800,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ApplicationTrackerScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildQuickActionCard(
                  context,
                  icon: Icons.calendar_today_outlined,
                  label: 'Scheduled\nViewings',
                  color: const Color(0xFFEDE7F6),
                  iconColor: Colors.purple.shade800,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ScheduledViewingsScreen()),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _buildQuickActionCard(
                  context,
                  icon: Icons.payment_outlined,
                  label: 'Payment\n& EFT',
                  color: const Color(0xFFE1F5FE),
                  iconColor: Colors.blue.shade800,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PaymentScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildQuickActionCard(
                  context,
                  icon: Icons.rate_review_outlined,
                  label: 'Reviews\n& Feedback',
                  color: const Color(0xFFE0F2F1),
                  iconColor: Colors.teal.shade800,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ReviewsScreen()),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Announcements Banner
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF3E0),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.primaryOrange.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(
                    color: AppTheme.primaryOrange,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.campaign_rounded, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'ANNOUNCEMENT',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: AppTheme.primaryOrange, letterSpacing: 1),
                      ),
                      SizedBox(height: 2),
                      Text('Available Accommodation Units', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      Text('Explore rooms near campus with all amenities included.', style: TextStyle(fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Featured Accommodation Units Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Available Rooms', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AvailableRoomsScreen()),
                ),
                child: Row(
                  children: const [
                    Text('View All', style: TextStyle(color: AppTheme.primaryOrange, fontWeight: FontWeight.bold)),
                    SizedBox(width: 4),
                    Icon(Icons.arrow_forward_ios, size: 12, color: AppTheme.primaryOrange),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          _isLoading
              ? const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()))
              : _filteredUnits.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 30),
                        child: Text('No accommodation units match your search.', style: TextStyle(color: Colors.grey)),
                      ),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _filteredUnits.length,
                      itemBuilder: (context, index) {
                        final unit = _filteredUnits[index];
                        return UnitCard(
                          unit: unit,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => UnitDetailsScreen(unit: unit)),
                            );
                          },
                        );
                      },
                    ),
        ],
      ),
    );
  }

  Widget _buildQuickActionCard(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            Icon(icon, color: iconColor, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: iconColor, height: 1.2),
            ),
          ],
        ),
      ),
    );
  }
}
