import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../config/theme.dart';
import '../../widgets/custom_button.dart';
import '../../services/payment_service.dart';
import '../../models/payment_model.dart';
import '../accommodation/available_rooms_screen.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({Key? key}) : super(key: key);

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final _paymentService = PaymentService();
  PaymentModel? _payment;
  bool _isLoading = true;
  bool _isProofUploaded = false;
  String _studentRef = 'STUDENT';

  @override
  void initState() {
    super.initState();
    _loadPayment();
  }

  void _loadPayment() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user != null) {
      final p = await _paymentService.getPaymentDetails(user.id);
      final studentNum = user.userMetadata?['student_number'] ?? user.email?.split('@').first ?? 'BB';
      if (mounted) {
        setState(() {
          _payment = p;
          _studentRef = studentNum;
          _isLoading = false;
        });
      }
    } else {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Payment & EFT')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.green.shade200),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: const [
                            Icon(Icons.check_circle, color: Colors.green),
                            SizedBox(width: 8),
                            Text('Secure Your Room via EFT', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Make payment to the banking details below using your reference, and upload your proof of payment for administrator verification.',
                          style: const TextStyle(fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Amount & Due Date
                  Card(
                    elevation: 1,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Monthly Rent', style: TextStyle(color: Colors.grey, fontSize: 12)),
                              Text(
                                _payment != null ? 'R${_payment!.amountDue.toStringAsFixed(0)}' : 'R4,500',
                                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.primaryOrange),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              const Text('Due Date', style: TextStyle(color: Colors.grey, fontSize: 12)),
                              Text(
                                _payment?.dueDate ?? '1st of Every Month',
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Banking Details
                  const Text('Payment Method: Bank Transfer / EFT', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 8),
                  Card(
                    elevation: 1,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Account Details:', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primaryOrange)),
                          const SizedBox(height: 8),
                          const Text('Account Holder: Big Brother Student Accommodation'),
                          const SizedBox(height: 4),
                          const Text('Bank: First National Bank (FNB)'),
                          const SizedBox(height: 4),
                          const Text('Account Number: 62849102934'),
                          const SizedBox(height: 4),
                          const Text('Branch Code: 250655'),
                          const SizedBox(height: 4),
                          Text('Payment Reference: BB-$_studentRef'),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  CustomButton(
                    text: _isProofUploaded ? 'Proof Uploaded Successfully ✓' : 'Upload Proof of Payment (EFT)',
                    icon: Icons.upload_file,
                    onPressed: () {
                      setState(() => _isProofUploaded = true);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Proof of payment received for admin verification!'), backgroundColor: Colors.green),
                      );
                    },
                  ),
                ],
              ),
            ),
    );
  }
}
