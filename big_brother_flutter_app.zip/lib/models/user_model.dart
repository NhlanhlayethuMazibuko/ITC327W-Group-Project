class UserModel {
  final String id;
  final String fullName;
  final String email;
  final String studentNumber;
  final String? phoneNumber;

  UserModel({
    required this.id,
    required this.fullName,
    required this.email,
    required this.studentNumber,
    this.phoneNumber,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      fullName: json['full_name'] ?? '',
      email: json['email'] ?? '',
      studentNumber: json['student_number'] ?? '',
      phoneNumber: json['phone_number'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'full_name': fullName,
      'email': email,
      'student_number': studentNumber,
      'phone_number': phoneNumber,
    };
  }
}
