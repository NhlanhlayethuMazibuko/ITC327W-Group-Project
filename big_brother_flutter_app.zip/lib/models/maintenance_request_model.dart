class MaintenanceRequestModel {
  final String id;
  final String referenceCode;
  final String category; // Plumbing, Electrical, Furniture, etc.
  final String priority; // High, Medium, Low
  final String description;
  final String? photoUrl;
  final String status; // Pending, In Progress, Resolved
  final String createdAt;

  MaintenanceRequestModel({
    required this.id,
    required this.referenceCode,
    required this.category,
    required this.priority,
    required this.description,
    this.photoUrl,
    required this.status,
    required this.createdAt,
  });

  factory MaintenanceRequestModel.fromJson(Map<String, dynamic> json) {
    return MaintenanceRequestModel(
      id: json['id'] ?? '',
      referenceCode: json['reference_code'] ?? '',
      category: json['category'] ?? '',
      priority: json['priority'] ?? 'Medium',
      description: json['description'] ?? '',
      photoUrl: json['photo_url'],
      status: json['status'] ?? 'Pending',
      createdAt: json['created_at'] ?? '',
    );
  }
}
