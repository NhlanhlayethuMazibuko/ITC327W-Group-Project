class PaymentModel {
  final String id;
  final String applicationId;
  final double amountDue;
  final String dueDate;
  final String paymentMethod;
  final String status; // Pending Verification, Paid
  final String? proofOfPaymentUrl;

  PaymentModel({
    required this.id,
    required this.applicationId,
    required this.amountDue,
    required this.dueDate,
    required this.paymentMethod,
    required this.status,
    this.proofOfPaymentUrl,
  });

  factory PaymentModel.fromJson(Map<String, dynamic> json) {
    return PaymentModel(
      id: json['id'] ?? '',
      applicationId: json['application_id'] ?? '',
      amountDue: (json['amount_due'] as num?)?.toDouble() ?? 4500.0,
      dueDate: json['due_date'] ?? '',
      paymentMethod: json['payment_method'] ?? 'Bank Transfer/EFT',
      status: json['status'] ?? 'Pending Verification',
      proofOfPaymentUrl: json['proof_of_payment_url'],
    );
  }
}
