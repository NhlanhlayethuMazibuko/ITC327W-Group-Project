class AccommodationUnit {
  final String id;
  final String title;
  final String type; // e.g., 1-Bedroom Apartment, Single with Balcony
  final double pricePerMonth;
  final String status; // Available, Occupied
  final String location;
  final String description;
  final List<String> amenities; // Wi-Fi, Laundry, Security, Shuttle
  final String furnitureDetails;
  final String imageUrl;

  AccommodationUnit({
    required this.id,
    required this.title,
    required this.type,
    required this.pricePerMonth,
    required this.status,
    required this.location,
    required this.description,
    required this.amenities,
    required this.furnitureDetails,
    required this.imageUrl,
  });

  factory AccommodationUnit.fromJson(Map<String, dynamic> json) {
    return AccommodationUnit(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      type: json['type'] ?? '',
      pricePerMonth: (json['price_per_month'] as num?)?.toDouble() ?? 0.0,
      status: json['status'] ?? 'Available',
      location: json['location'] ?? 'Universitas, Bloemfontein',
      description: json['description'] ?? '',
      amenities: List<String>.from(json['amenities'] ?? []),
      furnitureDetails: json['furniture_details'] ?? '',
      imageUrl: json['image_url'] ?? '',
    );
  }
}
