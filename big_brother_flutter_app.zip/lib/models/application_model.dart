class ApplicationModel {
  final String id;
  final String studentId;
  final String unitId;
  final String fullName;
  final String email;
  final String phoneNumber;
  final String dateOfBirth;
  final String institution;
  final String studentNumber;
  final String yearOfStudy;
  final bool isNsfasFunded;
  final String parentName;
  final String parentEmail;
  final String parentContact;
  final String parentRelationship;
  final String status; // Submitted, Under Review, Approved, Rejected
  final Map<String, String> uploadedDocuments;

  ApplicationModel({
    required this.id,
    required this.studentId,
    required this.unitId,
    required this.fullName,
    required this.email,
    required this.phoneNumber,
    required this.dateOfBirth,
    required this.institution,
    required this.studentNumber,
    required this.yearOfStudy,
    required this.isNsfasFunded,
    required this.parentName,
    required this.parentEmail,
    required this.parentContact,
    required this.parentRelationship,
    required this.status,
    required this.uploadedDocuments,
  });

  factory ApplicationModel.fromJson(Map<String, dynamic> json) {
    Map<String, String> docs = {};
    if (json['uploaded_documents'] != null) {
      if (json['uploaded_documents'] is Map) {
        (json['uploaded_documents'] as Map).forEach((key, value) {
          docs[key.toString()] = value?.toString() ?? 'Attached';
        });
      }
    }

    return ApplicationModel(
      id: json['id']?.toString() ?? '',
      studentId: json['student_id']?.toString() ?? '',
      unitId: json['unit_id']?.toString() ?? '',
      fullName: json['full_name']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      phoneNumber: json['phone_number']?.toString() ?? '',
      dateOfBirth: json['date_of_birth']?.toString() ?? '',
      institution: json['institution']?.toString() ?? '',
      studentNumber: json['student_number']?.toString() ?? '',
      yearOfStudy: json['year_of_study']?.toString() ?? '',
      isNsfasFunded: json['is_nsfas_funded'] == true,
      parentName: json['parent_name']?.toString() ?? '',
      parentEmail: json['parent_email']?.toString() ?? '',
      parentContact: json['parent_contact']?.toString() ?? '',
      parentRelationship: json['parent_relationship']?.toString() ?? '',
      status: json['status']?.toString() ?? 'Submitted',
      uploadedDocuments: docs,
    );
  }
}
