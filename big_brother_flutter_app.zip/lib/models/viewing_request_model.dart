class ViewingRequestModel {
  final String id;
  final String referenceCode;
  final String unitTitle;
  final String location;
  final String preferredDate;
  final String timeSlot; // 10:00 AM / 2:00 PM
  final String status; // Pending, Approved, Confirmed

  ViewingRequestModel({
    required this.id,
    required this.referenceCode,
    required this.unitTitle,
    required this.location,
    required this.preferredDate,
    required this.timeSlot,
    required this.status,
  });

  factory ViewingRequestModel.fromJson(Map<String, dynamic> json) {
    return ViewingRequestModel(
      id: json['id'] ?? '',
      referenceCode: json['reference_code'] ?? '',
      unitTitle: json['unit_title'] ?? '',
      location: json['location'] ?? 'Universitas, Bloemfontein',
      preferredDate: json['preferred_date'] ?? '',
      timeSlot: json['time_slot'] ?? '',
      status: json['status'] ?? 'Pending',
    );
  }
}
