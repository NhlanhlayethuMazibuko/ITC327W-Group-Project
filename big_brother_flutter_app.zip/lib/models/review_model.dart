class ReviewModel {
  final String id;
  final String studentName;
  final int rating;
  final String comment;
  final String date;

  ReviewModel({
    required this.id,
    required this.studentName,
    required this.rating,
    required this.comment,
    required this.date,
  });

  factory ReviewModel.fromJson(Map<String, dynamic> json) {
    return ReviewModel(
      id: json['id'] ?? '',
      studentName: json['student_name'] ?? 'Anonymous Student',
      rating: json['rating'] ?? 5,
      comment: json['comment'] ?? '',
      date: json['date'] ?? '',
    );
  }
}
