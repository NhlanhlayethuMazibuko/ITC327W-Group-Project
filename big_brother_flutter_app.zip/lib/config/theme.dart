import 'package:flutter/material.dart';

class AppTheme {
  // Bright Vibrant Orange matching Screenshot_2026-10-19_164123.png
  static const Color primaryOrange = Color(0xFFFF8500);   // Dominant Orange (Banner, Pill Buttons, Focus, Highlights)
  static const Color darkBrown = Color(0xFF5A1E00);        // Dark Logo & Branding Text
  static const Color lightOrangeBg = Color(0xFFFFE0B2);    // Circular Icon Fill
  static const Color backgroundColor = Colors.white;       // Screen Background
  static const Color cardColor = Colors.white;             // Card Surface
  static const Color textColor = Color(0xFF222222);         // Heading Text
  static const Color subtextColor = Color(0xFF666666);      // Subtitle Grey Text

  // Backward compatibility aliases
  static const Color primaryRed = Color(0xFFFF8500);
  static const Color secondaryOrange = Color(0xFFE65100);

  static ThemeData get lightTheme {
    return ThemeData(
      primaryColor: primaryOrange,
      scaffoldBackgroundColor: backgroundColor,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryOrange,
        primary: primaryOrange,
        secondary: darkBrown,
        surface: cardColor,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: textColor),
        titleTextStyle: TextStyle(
          color: textColor,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryOrange,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28), // Pill / Stadium shape matching screenshot
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryOrange,
          side: const BorderSide(color: primaryOrange, width: 2),
          minimumSize: const Size(double.infinity, 50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28), // Pill / Stadium shape matching screenshot
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.grey.shade50,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(25),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(25),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(25),
          borderSide: const BorderSide(color: primaryOrange, width: 2),
        ),
      ),
    );
  }
}
