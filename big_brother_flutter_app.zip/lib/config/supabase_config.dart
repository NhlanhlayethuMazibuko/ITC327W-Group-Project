class SupabaseConfig {
  // ---------------------------------------------------------------------------
  // IMPORTANT: Registration / login will NOT work until these two values are
  // filled in with your real Supabase project credentials.
  //
  // Find them in the Supabase dashboard:
  //   Project Settings -> API
  //     - Project URL   -> supabaseUrl   (e.g. https://abcdxyz.supabase.co)
  //     - anon public   -> supabaseAnonKey
  // ---------------------------------------------------------------------------
  static const String supabaseUrl = 'YOUR_SUPABASE_PROJECT_URL';
  static const String supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';

  /// True only when real credentials have been provided.
  static bool get isConfigured =>
      supabaseUrl.startsWith('http') &&
      !supabaseUrl.contains('YOUR_') &&
      supabaseAnonKey.isNotEmpty &&
      !supabaseAnonKey.contains('YOUR_');
}
