import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/maintenance_request_model.dart';

class MaintenanceService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<MaintenanceRequestModel> submitRequest({
    required String category,
    required String priority,
    required String description,
    String? photoUrl,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw Exception('User is not authenticated. Please log in first.');
    }

    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final refCode = 'BB-MNT-${timestamp.substring(timestamp.length - 6)}';

    try {
      final res = await _client.from('maintenance_requests').insert({
        'student_id': user.id,
        'reference_code': refCode,
        'category': category,
        'priority': priority,
        'description': description,
        'photo_url': photoUrl,
        'status': 'Pending',
      }).select().single();

      return MaintenanceRequestModel.fromJson(res);
    } catch (e) {
      print('Supabase Maintenance Insert Error: $e');
      rethrow;
    }
  }

  Future<List<MaintenanceRequestModel>> getRequests() async {
    final user = _client.auth.currentUser;
    if (user == null) return [];

    try {
      final res = await _client
          .from('maintenance_requests')
          .select()
          .eq('student_id', user.id)
          .order('created_at', ascending: false);

      if (res != null && (res as List).isNotEmpty) {
        return (res as List).map((e) => MaintenanceRequestModel.fromJson(e)).toList();
      }
      return [];
    } catch (e) {
      print('Error fetching student maintenance requests: $e');
      return [];
    }
  }
}
