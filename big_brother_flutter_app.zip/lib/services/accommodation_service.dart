import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/accommodation_unit.dart';

class AccommodationService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<List<AccommodationUnit>> getAvailableUnits() async {
    try {
      final response = await _client
          .from('accommodation_units')
          .select();
      
      final list = response as List;
      if (list.isNotEmpty) {
        return list.map((e) => AccommodationUnit.fromJson(e)).toList();
      }
    } catch (e) {
      print('Error fetching accommodation units from Supabase: $e');
    }

    // Default mock data if Supabase table is empty or error occurs
    return [
      AccommodationUnit(
        id: '1',
        title: '1-Bedroom Apartment',
        type: '1-Bedroom',
        pricePerMonth: 4500.0,
        status: 'Available',
        location: 'Universitas, Bloemfontein',
        description: 'A private, comfortable room with a bed, study desk, storage space and access to shared accommodation facilities.',
        amenities: ['Wi-Fi', 'Laundry', 'Security', 'Shuttle'],
        furnitureDetails: 'Single bed, study desk, chair, wardrobe.',
        imageUrl: 'assets/images/unit1.jpg',
      ),
      AccommodationUnit(
        id: '2',
        title: '2-Bedroom Apartment',
        type: '2-Bedroom',
        pricePerMonth: 4500.0,
        status: 'Available',
        location: 'Universitas, Bloemfontein',
        description: 'Spacious 2-bedroom unit with modern fittings and proximity to campus.',
        amenities: ['Wi-Fi', 'Laundry', 'Security', 'Shuttle'],
        furnitureDetails: '2 beds, 2 desks, shared lounge area.',
        imageUrl: 'assets/images/unit3.jpg',
      ),
      AccommodationUnit(
        id: '3',
        title: 'Single Room with Balcony',
        type: 'Single Room',
        pricePerMonth: 4500.0,
        status: 'Available',
        location: 'Universitas, Bloemfontein',
        description: 'Cozy single room featuring a private balcony overlooking Universitas.',
        amenities: ['Wi-Fi', 'Laundry', 'Security', 'Shuttle'],
        furnitureDetails: 'Single bed, desk, wardrobe, private balcony seating.',
        imageUrl: 'assets/images/unit7.jpg',
      ),
    ];
  }
}
