import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/viewing_request_model.dart';

class ViewingService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<ViewingRequestModel> requestViewing({
    required String unitTitle,
    required String preferredDate,
    required String timeSlot,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw Exception('User is not authenticated. Please log in first.');
    }

    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final refCode = 'BB-VW-${timestamp.substring(timestamp.length - 6)}';

    try {
      final res = await _client.from('viewing_requests').insert({
        'student_id': user.id,
        'reference_code': refCode,
        'unit_title': unitTitle,
        'location': 'Universitas, Bloemfontein',
        'preferred_date': preferredDate,
        'time_slot': timeSlot,
        'status': 'Pending',
      }).select().single();

      return ViewingRequestModel.fromJson(res);
    } catch (e) {
      print('Supabase Viewing Insert Error: $e');
      rethrow;
    }
  }

  Future<List<ViewingRequestModel>> getScheduledViewings() async {
    final user = _client.auth.currentUser;
    if (user == null) return [];

    try {
      final response = await _client
          .from('viewing_requests')
          .select()
          .eq('student_id', user.id)
          .order('created_at', ascending: false);

      if (response != null && (response as List).isNotEmpty) {
        return (response as List).map((e) => ViewingRequestModel.fromJson(e)).toList();
      }
      return [];
    } catch (e) {
      print('Error fetching student scheduled viewings: $e');
      return [];
    }
  }
}
