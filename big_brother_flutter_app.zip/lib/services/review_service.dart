import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/review_model.dart';

class ReviewService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<void> submitReview({required int rating, required String comment}) async {
    try {
      await _client.from('reviews').insert({
        'rating': rating,
        'comment': comment,
        'created_at': DateTime.now().toIso8601String(),
      });
    } catch (_) {}
  }

  Future<List<ReviewModel>> getReviews() async {
    try {
      final res = await _client.from('reviews').select().order('created_at', ascending: false);
      return (res as List).map((e) => ReviewModel.fromJson(e)).toList();
    } catch (_) {
      return [
        ReviewModel(
          id: '1',
          studentName: 'Thabo Mufukeng',
          rating: 5,
          comment: 'Great student accommodation! Very safe and close to UFS campus.',
          date: '10 Oct 2026',
        ),
      ];
    }
  }
}
