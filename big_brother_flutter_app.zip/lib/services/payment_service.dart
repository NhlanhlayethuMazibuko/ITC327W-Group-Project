import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/payment_model.dart';

class PaymentService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<PaymentModel?> getPaymentDetails(String studentId) async {
    try {
      final res = await _client
          .from('payments')
          .select()
          .eq('student_id', studentId)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (res != null) {
        return PaymentModel.fromJson(res);
      }
      return null;
    } catch (e) {
      print('Error fetching student payment: $e');
      return null;
    }
  }

  Future<void> uploadProofOfPayment(String paymentId, String filePath) async {
    try {
      await _client.from('payments').update({
        'status': 'Proof Uploaded',
        'proof_of_payment_url': filePath,
      }).eq('id', paymentId);
    } catch (e) {
      print('Error updating proof of payment: $e');
    }
  }
}
