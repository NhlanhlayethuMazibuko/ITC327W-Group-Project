import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient _client = Supabase.instance.client;

  /// Sign in an existing student with email and password
  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    return await _client.auth.signInWithPassword(
      email: email.trim(),
      password: password.trim(),
    );
  }

  /// Register a new student account
  Future<AuthResponse> signUp({
    required String fullName,
    required String email,
    required String studentNumber,
    required String password,
  }) async {
    final cleanFullName = fullName.trim();
    final cleanEmail = email.trim();
    final cleanStudentNumber = studentNumber.trim();
    final cleanPassword = password.trim();

    final response = await _client.auth.signUp(
      email: cleanEmail,
      password: cleanPassword,
      data: {
        'full_name': cleanFullName,
        'student_number': cleanStudentNumber,
      },
    );

    // When Supabase returns a user with an empty identities list, it means an
    // account with this email already exists (Supabase obfuscates this for
    // security). Surface a clear, actionable error instead of a silent no-op.
    final user = response.user;
    if (user == null) {
      throw Exception('Account could not be created. Please try again.');
    }
    if (user.identities != null && user.identities!.isEmpty) {
      throw Exception('An account with this email already exists. Please log in instead.');
    }

    // Only write the profile row when we actually have an authenticated session
    // (i.e. email confirmation is disabled). With confirmation enabled there is
    // no session yet, so a client-side insert would be blocked by RLS.
    if (response.session != null) {
      try {
        await _client.from('profiles').upsert({
          'id': user.id,
          'full_name': cleanFullName,
          'email': cleanEmail,
          'student_number': cleanStudentNumber,
        });
      } catch (e) {
        // A database trigger may already create this row; ignore duplicates.
        print('Profile sync handled by trigger or deferred: $e');
      }
    }

    return response;
  }

  /// Option 3: Direct in-app password reset using Student Identity (No email required)
  Future<void> resetPasswordWithStudentNumber({
    required String email,
    required String studentNumber,
    required String newPassword,
  }) async {
    final res = await _client.rpc('reset_student_password', params: {
      'user_email': email.trim(),
      'student_no': studentNumber.trim(),
      'new_password': newPassword.trim(),
    });

    if (res != null && res is Map && res['success'] == false) {
      throw Exception(res['message'] ?? 'Password reset failed');
    }
  }

  /// Send password recovery email (if SMTP is configured)
  Future<void> sendPasswordResetEmail(String email) async {
    await _client.auth.resetPasswordForEmail(email.trim());
  }

  /// Verify 6-digit OTP code
  Future<AuthResponse> verifyOtp({
    required String email,
    required String token,
    OtpType type = OtpType.recovery,
  }) async {
    return await _client.auth.verifyOTP(
      email: email.trim(),
      token: token.trim(),
      type: type,
    );
  }

  /// Update password for the currently authenticated session
  Future<UserResponse> updatePassword(String newPassword) async {
    return await _client.auth.updateUser(
      UserAttributes(password: newPassword.trim()),
    );
  }

  /// Sign out the current student session
  Future<void> signOut() async {
    await _client.auth.signOut();
  }

  /// Get current authenticated Supabase Auth User
  User? get currentUser => _client.auth.currentUser;

  /// Check if user has an active authenticated session
  bool get isAuthenticated => _client.auth.currentSession != null;
}
