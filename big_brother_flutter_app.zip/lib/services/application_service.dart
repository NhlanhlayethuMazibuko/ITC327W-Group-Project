import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/application_model.dart';

class ApplicationService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<String> submitApplication(ApplicationModel application) async {
    final user = _client.auth.currentUser;
    final studentId = user?.id ?? (application.studentId.isNotEmpty ? application.studentId : null);

    if (studentId == null) {
      throw Exception('User is not authenticated. Please log in first.');
    }

    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final defaultRef = 'A${timestamp.substring(timestamp.length - 4)}';

    try {
      final res = await _client.from('applications').insert({
        'student_id': studentId,
        'unit_id': application.unitId.isNotEmpty ? application.unitId : null,
        'full_name': application.fullName,
        'email': application.email,
        'phone_number': application.phoneNumber,
        'date_of_birth': application.dateOfBirth,
        'institution': application.institution,
        'student_number': application.studentNumber,
        'year_of_study': application.yearOfStudy,
        'is_nsfas_funded': application.isNsfasFunded,
        'parent_name': application.parentName,
        'parent_email': application.parentEmail,
        'parent_contact': application.parentContact,
        'parent_relationship': application.parentRelationship,
        'status': 'Submitted',
        'uploaded_documents': application.uploadedDocuments,
      }).select().single();

      return res['id']?.toString() ?? defaultRef;
    } catch (e) {
      print('Supabase Application Insert Error: $e');
      rethrow;
    }
  }

  Future<ApplicationModel?> getLatestApplication(String studentId) async {
    try {
      final response = await _client
          .from('applications')
          .select()
          .eq('student_id', studentId)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (response != null) {
        return ApplicationModel.fromJson(response);
      }
      return null;
    } catch (e) {
      print('Error fetching student application: $e');
      return null;
    }
  }

  Future<List<ApplicationModel>> getAllStudentApplications(String studentId) async {
    try {
      final response = await _client
          .from('applications')
          .select()
          .eq('student_id', studentId)
          .order('created_at', ascending: false);

      if (response != null && (response as List).isNotEmpty) {
        return (response as List).map((e) => ApplicationModel.fromJson(e)).toList();
      }
      return [];
    } catch (e) {
      print('Error fetching applications list: $e');
      return [];
    }
  }
}
