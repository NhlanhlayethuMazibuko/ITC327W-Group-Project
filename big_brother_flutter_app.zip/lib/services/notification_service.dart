import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/notification_model.dart';

class NotificationService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<List<NotificationModel>> getNotifications() async {
    try {
      final res = await _client.from('notifications').select();
      return (res as List).map((e) => NotificationModel.fromJson(e)).toList();
    } catch (_) {
      return [
        NotificationModel(
          id: '1',
          title: 'Accommodation Application Approved',
          message: 'Your application for accommodation at Big Brother Student Accommodations has been approved!',
          timeAgo: '5m ago',
          isRead: false,
          category: 'Application',
        ),
        NotificationModel(
          id: '2',
          title: 'Viewing Appointment Confirmed',
          message: 'Your viewing appointment for Single Room (Females) at Universitas, Bloemfontein has been confirmed.',
          timeAgo: '14:00',
          isRead: false,
          category: 'Viewing',
        ),
        NotificationModel(
          id: '3',
          title: 'Secure Your Space Today!',
          message: 'Apply for accommodation using our easy application form.',
          timeAgo: '1d ago',
          isRead: true,
          category: 'Announcement',
        ),
      ];
    }
  }

  Future<void> markAllAsRead() async {
    try {
      await _client.from('notifications').update({'is_read': true}).neq('id', '');
    } catch (_) {}
  }
}
