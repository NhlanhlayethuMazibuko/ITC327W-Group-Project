import 'package:flutter/material.dart';
import '../config/theme.dart';

/// A smart image widget that renders an accommodation unit image regardless of
/// whether [imageUrl] is a remote URL (http/https) or a bundled asset path.
///
/// It always falls back to a branded placeholder icon when the image is empty,
/// missing, or fails to load — so the UI never shows a broken/blank box.
class UnitImage extends StatelessWidget {
  final String imageUrl;
  final double height;
  final double borderRadius;
  final double iconSize;

  const UnitImage({
    Key? key,
    required this.imageUrl,
    this.height = 140,
    this.borderRadius = 12,
    this.iconSize = 55,
  }) : super(key: key);

  Widget _placeholder() {
    return Container(
      height: height,
      width: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3E0),
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      child: Center(
        child: Icon(Icons.apartment_rounded, size: iconSize, color: AppTheme.primaryOrange),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final url = imageUrl.trim();
    if (url.isEmpty) return _placeholder();

    final bool isNetwork = url.startsWith('http://') || url.startsWith('https://');

    Widget image;
    if (isNetwork) {
      image = Image.network(
        url,
        height: height,
        width: double.infinity,
        fit: BoxFit.cover,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return Container(
            height: height,
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0xFFFFF3E0),
              borderRadius: BorderRadius.circular(borderRadius),
            ),
            child: const Center(
              child: CircularProgressIndicator(color: AppTheme.primaryOrange),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) => _placeholder(),
      );
    } else {
      image = Image.asset(
        url,
        height: height,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _placeholder(),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: image,
    );
  }
}
